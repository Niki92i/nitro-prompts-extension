// Popup script for Nitro Prompts extension
document.addEventListener('DOMContentLoaded', function() {
  // DOM elements
  const enableModule = document.getElementById('enableModule');
  const intelligenceLevel = document.getElementById('intelligenceLevel');
  const transparency = document.getElementById('transparency');
  const transparencyValue = document.getElementById('transparencyValue');
  const moduleSize = document.getElementById('moduleSize');
  const geminiApiKey = document.getElementById('geminiApiKey');
  const testAI = document.getElementById('testAI');
  const aiStatus = document.getElementById('aiStatus');
  const clearApiKey = document.getElementById('clearApiKey');
  const openSettings = document.getElementById('openSettings');
  const resetSettings = document.getElementById('resetSettings');

  // Default settings
  const defaultSettings = {
    enabled: false,
    intelligenceLevel: 'intermediate',
    transparency: 80,
    moduleSize: 'medium',
    position: { x: 20, y: 20 },
    customPrompts: [],
    geminiApiKey: ''
  };

  // Load settings from storage
  async function loadSettings() {
    try {
      const result = await chrome.storage.sync.get('nitroPromptsSettings');
      const settings = result.nitroPromptsSettings || defaultSettings;
      
      // Get the current module state from the active tab
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.url && tab.url.startsWith('http')) {
          const response = await chrome.tabs.sendMessage(tab.id, { action: 'getModuleState' });
          if (response && response.success) {
            // Sync the checkbox with the actual module state
            settings.enabled = response.visible;
            console.log('Synced with actual module state:', response.visible);
          }
        }
      } catch (error) {
        console.log('Could not sync with content script, using stored settings');
      }
      
      enableModule.checked = settings.enabled;
      intelligenceLevel.value = settings.intelligenceLevel;
      transparency.value = settings.transparency;
      transparencyValue.textContent = `${settings.transparency}%`;
      moduleSize.value = settings.moduleSize;
      geminiApiKey.value = settings.geminiApiKey || '';
      
      // Set initial border color for API key field
      geminiApiKey.style.borderColor = settings.geminiApiKey ? '#28a745' : '#ddd';
      
      return settings;
    } catch (error) {
      console.error('Error loading settings:', error);
      return defaultSettings;
    }
  }

  // Save settings to storage
  async function saveSettings(settings) {
    try {
      await chrome.storage.sync.set({ nitroPromptsSettings: settings });
      
      // Send message to content script to update module
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url && tab.url.startsWith('http')) {
        try {
          await chrome.tabs.sendMessage(tab.id, {
            action: 'updateSettings',
            settings: settings
          });
        } catch (error) {
          console.log('Content script not ready yet, settings will be applied on next page load');
        }
      }
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  }

  // Toggle module visibility
  async function toggleModule(show) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url && tab.url.startsWith('http')) {
        try {
          await chrome.tabs.sendMessage(tab.id, {
            action: show ? 'showModule' : 'hideModule'
          });
        } catch (error) {
          console.log('Content script not ready, module will be toggled on next page load');
        }
      }
    } catch (error) {
      console.error('Error toggling module:', error);
    }
  }

  // Event listeners
  enableModule.addEventListener('change', async function() {
    console.log('Toggle clicked, checked state:', this.checked);
    
    // Load current settings
    const settings = await loadSettings();
    console.log('Current settings:', settings);
    
    // Update the enabled state based on the checkbox
    settings.enabled = this.checked;
    console.log('Updated settings:', settings);
    
    // Save the updated settings
    await saveSettings(settings);
    
    // Toggle module visibility based on the new state
    await toggleModule(this.checked);
    
    // Show feedback to user
    const status = this.checked ? 'enabled' : 'disabled';
    console.log('Showing notification:', status);
    showNotification(`Prompt module ${status}!`, 'success');
    
    // Verify the change was applied
    setTimeout(async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.url && tab.url.startsWith('http')) {
          const response = await chrome.tabs.sendMessage(tab.id, { action: 'getModuleState' });
          if (response && response.success) {
            console.log('Module state after toggle:', response.visible, 'Expected:', this.checked);
            if (response.visible !== this.checked) {
              console.warn('Module state mismatch detected!');
            }
          }
        }
      } catch (error) {
        console.log('Could not verify module state');
      }
    }, 100);
  });

  intelligenceLevel.addEventListener('change', async function() {
    const settings = await loadSettings();
    settings.intelligenceLevel = this.value;
    await saveSettings(settings);
    showNotification('Intelligence level updated!', 'success');
  });

  transparency.addEventListener('input', async function() {
    const value = this.value;
    transparencyValue.textContent = `${value}%`;
    
    // Update settings immediately
    const settings = await loadSettings();
    settings.transparency = parseInt(value);
    
    // Apply transparency change in real-time
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url && tab.url.startsWith('http')) {
        await chrome.tabs.sendMessage(tab.id, {
          action: 'updateTransparency',
          transparency: parseInt(value)
        });
      }
    } catch (error) {
      console.log('Could not apply transparency in real-time');
    }
    
    // Save settings
    await saveSettings(settings);
  });

  // Add change event for when user finishes adjusting
  transparency.addEventListener('change', async function() {
    showNotification(`Transparency set to ${this.value}%`, 'success');
  });

  moduleSize.addEventListener('change', async function() {
    const settings = await loadSettings();
    settings.moduleSize = this.value;
    await saveSettings(settings);
    showNotification('Module size updated!', 'success');
  });

  geminiApiKey.addEventListener('input', async function() {
    const settings = await loadSettings();
    settings.geminiApiKey = this.value;
    await saveSettings(settings);
    
    // Show visual feedback
    this.style.borderColor = this.value ? '#28a745' : '#ddd';
    if (this.value) {
      showNotification('API key saved!', 'success');
    }
    
    // Log the input for debugging
    console.log('Input event fired, value length:', this.value.length);
  });

  // Simple paste event handler
  geminiApiKey.addEventListener('paste', function(e) {
    console.log('Paste event detected');
    // Let the browser handle the paste naturally
    // The input event will catch the change
  });

  // Add focus event to ensure the field is ready for input
  geminiApiKey.addEventListener('focus', function() {
    this.select(); // Select all text when focused
    this.style.borderColor = '#667eea';
    this.style.boxShadow = '0 0 0 2px rgba(102, 126, 234, 0.3)';
    console.log('API key field focused');
  });

  // Add blur event to reset border color
  geminiApiKey.addEventListener('blur', function() {
    this.style.borderColor = this.value ? '#28a745' : '#ddd';
    this.style.boxShadow = 'none';
    console.log('API key field blurred, value length:', this.value.length);
  });

  // Add a manual paste button as fallback
  const pasteButton = document.createElement('button');
  pasteButton.textContent = 'Paste';
  pasteButton.className = 'btn-small paste-btn';
  pasteButton.addEventListener('click', async function() {
    // Focus the field and trigger paste
    geminiApiKey.focus();
    
    try {
      // Try to use the clipboard API first
      const text = await navigator.clipboard.readText();
      if (text) {
        geminiApiKey.value = text;
        geminiApiKey.dispatchEvent(new Event('input', { bubbles: true }));
        showNotification('API key pasted!', 'success');
        console.log('API key pasted via clipboard API');
        return;
      }
    } catch (error) {
      console.log('Clipboard API failed, trying alternative method');
    }
    
    // Fallback: Create a temporary input and use execCommand
    const tempInput = document.createElement('input');
    tempInput.style.position = 'absolute';
    tempInput.style.left = '-9999px';
    tempInput.style.top = '-9999px';
    document.body.appendChild(tempInput);
    
    try {
      tempInput.focus();
      const success = document.execCommand('paste');
      if (success && tempInput.value) {
        geminiApiKey.value = tempInput.value;
        geminiApiKey.dispatchEvent(new Event('input', { bubbles: true }));
        showNotification('API key pasted!', 'success');
        console.log('API key pasted via execCommand');
      } else {
        showNotification('No text in clipboard', 'error');
      }
    } catch (error) {
      console.error('execCommand failed:', error);
      showNotification('Paste failed. Use Ctrl+V instead.', 'error');
    } finally {
      document.body.removeChild(tempInput);
    }
  });
  
  // Insert the paste button after the clear button
  clearApiKey.parentNode.insertBefore(pasteButton, clearApiKey.nextSibling);

  // Add a simple test button to verify the field works
  const testButton = document.createElement('button');
  testButton.textContent = 'Test';
  testButton.className = 'btn-small';
  testButton.style.marginLeft = '5px';
  testButton.style.background = '#ffc107';
  testButton.addEventListener('click', function() {
    const testKey = 'test-api-key-' + Date.now();
    geminiApiKey.value = testKey;
    geminiApiKey.dispatchEvent(new Event('input', { bubbles: true }));
    showNotification('Test key set!', 'success');
  });
  
  // Insert the test button after the paste button
  clearApiKey.parentNode.insertBefore(testButton, pasteButton.nextSibling);

  // Add right-click context menu paste handler
  geminiApiKey.addEventListener('contextmenu', function(e) {
    // Don't prevent default - let the context menu show
    console.log('Right-click on API key field');
  });

  clearApiKey.addEventListener('click', async function() {
    geminiApiKey.value = '';
    geminiApiKey.style.borderColor = '#ddd';
    const settings = await loadSettings();
    settings.geminiApiKey = '';
    await saveSettings(settings);
    showNotification('API key cleared!', 'success');
  });

  testAI.addEventListener('click', async function() {
    const settings = await loadSettings();
    if (!settings.geminiApiKey) {
      aiStatus.textContent = '❌ No API key provided';
      aiStatus.className = 'status-indicator error';
      return;
    }

    aiStatus.textContent = '🔄 Testing connection...';
    aiStatus.className = 'status-indicator loading';

    try {
      // Test AI connection by sending message to content script
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url && tab.url.startsWith('http')) {
        const response = await chrome.tabs.sendMessage(tab.id, {
          action: 'testAI',
          apiKey: settings.geminiApiKey
        });
        
        if (response && response.success) {
          aiStatus.textContent = '✅ AI connection successful!';
          aiStatus.className = 'status-indicator success';
        } else {
          aiStatus.textContent = '❌ AI connection failed: ' + (response.error || 'Unknown error');
          aiStatus.className = 'status-indicator error';
        }
      } else {
        aiStatus.textContent = '❌ No active tab found';
        aiStatus.className = 'status-indicator error';
      }
    } catch (error) {
      aiStatus.textContent = '❌ Test failed: ' + error.message;
      aiStatus.className = 'status-indicator error';
    }
  });

  openSettings.addEventListener('click', function() {
    chrome.tabs.create({ url: 'settings.html' });
  });

  resetSettings.addEventListener('click', async function() {
    if (confirm('Are you sure you want to reset all settings to default?')) {
      await saveSettings(defaultSettings);
      await loadSettings();
      
      // Notify content script
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.url && tab.url.startsWith('http')) {
          await chrome.tabs.sendMessage(tab.id, {
            action: 'resetSettings'
          });
        }
      } catch (error) {
        console.log('Content script not ready');
      }
      
      showNotification('Settings reset to default!', 'success');
    }
  });

  // Show notification function
  function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = `
      position: fixed;
      top: 10px;
      right: 10px;
      background: ${type === 'success' ? '#28a745' : '#667eea'};
      color: white;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
      z-index: 10000;
      animation: slideIn 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 2000);
  }

  // Initialize popup
  loadSettings();
}); 